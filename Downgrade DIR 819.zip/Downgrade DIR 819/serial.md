# Serial Connector (J2 Connector)

Connection configurtion: 115200 8n1

Order of pins: VCC, GND, TX, RX

[![J2 Connector](files/images/J2_Connector.jpg)](https://openwrt.org/docs/techref/hardware/port.serial)

# Thank's to

Gaspare Bruno <gaspare@anlix.io>
